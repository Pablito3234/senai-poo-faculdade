package menu;

import entidades.Produto;
import servicos.ContadorCodigo;

import java.util.Scanner;

public class OperacoesObjetos {
    private static Scanner entrada = new Scanner(System.in);
    public static Produto criarProduto(ContadorCodigo contadorCodigo){
        while (true) {
            try {
                System.out.println("Digite um preco");
                Float preco = entrada.nextFloat();

                System.out.println("Digite um nome");
                String nome = entrada.next();

                return new Produto(preco, nome, contadorCodigo);
            } catch (IllegalArgumentException exception){
                System.out.println(exception.getMessage());
            }
        }
    }
}
