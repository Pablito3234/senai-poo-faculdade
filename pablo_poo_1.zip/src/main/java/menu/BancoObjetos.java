package menu;

import entidades.Produto;

import java.util.ArrayList;

public class BancoObjetos {
    ArrayList<Produto> produtos;

    public BancoObjetos(ArrayList<Produto> produtos) {
        this.produtos = produtos;
    }

    public void adicionarProduto(Produto produto){
        produtos.add(produto);
    }
}
