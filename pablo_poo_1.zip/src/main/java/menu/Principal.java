package menu;

import entidades.Produto;
import servicos.ContadorCodigo;

import java.util.ArrayList;
import java.util.Scanner;

import static menu.OperacoesObjetos.*;

public class Principal {
    private static Scanner entrada = new Scanner(System.in);
    private static BancoObjetos bancoObjetos = new BancoObjetos(new ArrayList<>());
    private static ContadorCodigo contadorCodigo = new ContadorCodigo();

    public static void main(String[] args) {
        menuPrincipal();
    }

    private static void menuPrincipal() {
        boolean sair = false;
        while (!sair){
            System.out.println("""
                    Digite uma opção
                    [P]: Produtos
                    [C]: Clientes
                    [E]: Estoque
                    [V]: Vendas
                    [Qualquer outra coisa]: Sair
                    """);
            String opcao = entrada.nextLine().toLowerCase();

            switch (opcao) {
                case "p":
                    opcoesCrudProduto();
                    break;
                case "c":
                    break;
                case "e":
                    break;
                case "v":
                    break;
                default:
                    System.out.println("Saindo");
                    sair = true;
                    break;
            }
        }
    }

    private static void opcoesCrudProduto() {
        System.out.println("""
                Digite uma opção
                [C]: Criar
                [V]: Ver
                [A]: Atualizar
                [D]: Deletar
                [Qualquer outra coisa]: Voltar
                """);
        String opcao = entrada.nextLine().toLowerCase();

        switch (opcao){
            case "c":
                Produto novoProduto = criarProduto(contadorCodigo);
                bancoObjetos.adicionarProduto(novoProduto);
                break;
            case "v":
                break;
            case "a":
                break;
            case "d":
                break;
            default:
                System.out.println("Opcao invalida");
                break;
        }
    }
}
