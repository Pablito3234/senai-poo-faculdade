package servicos;

public class ContadorCodigo {
    Integer codigoAtual = 0;

    public ContadorCodigo() {
    }

    public Integer gerarNovoCodigo(){
        this.codigoAtual += 1;
        return this.codigoAtual;
    }
}