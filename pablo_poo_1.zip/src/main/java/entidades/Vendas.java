package entidades;

public class Vendas {
}
