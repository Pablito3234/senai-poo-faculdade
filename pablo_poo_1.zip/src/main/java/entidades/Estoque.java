package entidades;

public class Estoque {
}
