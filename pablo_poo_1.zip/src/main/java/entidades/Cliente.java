package entidades;

public class Cliente {
}
